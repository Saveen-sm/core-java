package inputdata;
import java.util.Scanner;
public class CelToFar {

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			float F,C;
			System.out.println("Enter Celsius Temperature" );
			C=sc.nextFloat();
			F=(C*1.8f)+32;
			System.out.println("The Fahrenheit Temperature is="+F);
			sc.close();
		}
	}
