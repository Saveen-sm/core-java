package inputdata;
import java.util.Scanner;
public class InputData {
	public static void main(String[] args) {
		String name;
		int age;
		float salary;
		char gen;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name");
		name=sc.nextLine();
		System.out.println("Enter age ");
		age=sc.nextInt();
		System.out.println("Enter gen");
		gen=sc.next().charAt(0);
		System.out.println("Enter salary");
		salary=sc.nextFloat();
		System.out.println("Enter Name="+ name);
		System.out.println("Enter age="+age);
		System.out.println("Enter gen="+gen);
		System.out.println("Enter salary="+salary);
		sc.close();
	}

}
