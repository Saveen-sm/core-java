package inputdata;
import java.util.Scanner;

public class FarToCel {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		float F,C;
		System.out.println("Enter Fahrenheit Temperature" );
		F=sc.nextFloat();
		C=(F-32)*0.5556f;
		System.out.println(" The Celsius Temperature is="+C);	
		sc.close();
	}
}

